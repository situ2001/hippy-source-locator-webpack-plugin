# @situ2001/code-quality

Shared Oxlint / Oxfmt presets, readability rules, workspace import boundaries, and TypeScript project analysis. Requires Node.js 22.18+ within the 22.x series, or Node.js 24 or later.

## Installation and basic configuration

Run `pnpm pack --pack-destination /target/directory` in this directory. In the consuming repository, install the generated `.tgz` along with the `oxlint`, `oxfmt`, and `oxlint-tsgolint` versions listed in [package.json](./package.json)'s `peerDependencies`.

Create `oxlint.config.ts` at the repository root:

```ts
import base from "@situ2001/code-quality/oxlint";
import react from "@situ2001/code-quality/react";

export default {
  extends: [base, react],
  options: { typeAware: true },
  ignorePatterns: ["generated/**"],
};
```

Omit `react` for repositories that do not use React. Keep `typeAware` in the root configuration and customize checks through `rules` and `overrides`.

Create `oxfmt.config.ts`:

```ts
import base from "@situ2001/code-quality/oxfmt";

export default {
  ...base,
  ignorePatterns: ["generated/**"],
};
```

Configure ignore patterns and Tailwind sorting in the consuming repository. For Tailwind, set `sortTailwindcss.stylesheet` and `sortTailwindcss.functions`.

For separate naming and complexity checks, extend `@situ2001/code-quality/naming` or `@situ2001/code-quality/complexity` in a dedicated configuration and run `oxlint -c filename .`. Keep the main configuration for correctness checks.

## Workspace boundaries and domain inputs

To check workspace import boundaries, extend the main configuration with `createWorkspaceConfig`:

```ts
import base from "@situ2001/code-quality/oxlint";
import { createWorkspaceConfig } from "@situ2001/code-quality/workspace";

export default {
  extends: [
    base,
    createWorkspaceConfig({
      directory: import.meta.dirname,
      packages: ["packages/*", "apps/*", "!packages/excluded"],
    }),
  ],
  options: { typeAware: true },
};
```

`directory` is the workspace root; `packages` contains relative directory globs with `!` exclusions. The root package is included automatically. Cross-package imports must use the target package's name and a declared `package.json.exports` entry.

The base preset loads the readability plugin. Enable `readability/explicit-domain-inputs` through `overrides` for directories where parameters and fields must be required, absent values use `null`, and parameter defaults are prohibited. For standalone use, load the plugin from `@situ2001/code-quality/readability`.

## Project analysis commands

To check string addition, non-boolean `||`, and suppression comments missing rule names or reasons, create `project-policy.config.ts`:

```ts
import type { ProjectPolicyConfig } from "@situ2001/code-quality/project-policy";

export default {
  configs: ["tsconfig.json"],
  include: ["src/**/*.{ts,tsx}"],
  ignore: ["**/node_modules/**", "generated/**"],
} satisfies ProjectPolicyConfig;
```

Run `code-quality project project-policy.config.ts`.

To find unused exports and unreachable declarations, create `exports.config.ts`:

```ts
import type { ExportsConfig } from "@situ2001/code-quality/exports";

export default {
  configs: ["tsconfig.json"],
  entry: ["src/main.ts", "test/**/*.test.ts", "packages/*/package.json"],
  ignore: ["generated/**"],
} satisfies ExportsConfig;
```

Run `code-quality exports exports.config.ts`. A `package.json` in `entry` expands to its `exports` entry points. Mark APIs consumed by frameworks, external consumers, or plugins with `/** @public -- reason */` so the analysis retains them.

The export analysis combines import resolutions from all configured projects, including their browser and Node.js conditions. For workspace imports that resolve to emitted declaration files, enable TypeScript `declarationMap` and include the original sources in the configured projects; single-source declaration maps connect references back to the original modules.

For both commands, ensure the TypeScript projects cover the source files being analyzed and add build output to `ignore`. Paths resolve relative to the configuration file's directory; issues produce exit code 1.

For programmatic use, import `checkProject` from `@situ2001/code-quality/project-policy` or `checkExports` from `@situ2001/code-quality/exports`. Pass the corresponding configuration fields and a `directory` against which paths resolve.

## Development in this repository

`pnpm install` builds the package. After source changes, run `pnpm quality:build` from the repository root before using the root lint commands. Use `pnpm test:lint` for rule tests and `pnpm lint` to check the repository's integration.

Project analysis uses the `typescript/unstable/*` APIs from the TypeScript version pinned in [package.json](./package.json). Run the rule tests when upgrading TypeScript.
